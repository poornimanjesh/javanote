package constructor;

class NoReturn
{
	int accNum;
	
	NoReturn()
	{
		int accNum = 12356789;
		this.accNum = accNum;
	}
}


public class ConstructorNoReturn {
	public static void main(String[] args) {
		NoReturn nr = new NoReturn();
		System.out.println(nr.accNum);
	}
}
