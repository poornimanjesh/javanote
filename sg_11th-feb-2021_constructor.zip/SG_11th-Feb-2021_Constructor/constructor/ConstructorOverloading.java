package constructor;

class Overload
{
	//1. The no. of arguments used in the constructors should be different
	Overload()
	{
		System.out.println("Default Constructor");
	}
	
	Overload(String name)
	{
		System.out.println("1 string param");
	}
	
	
	//2. The datatype of the arguments used in the constructors should be different.
	Overload(int age)
	{
		System.out.println("1 int param");
	}
	
	
	Overload(double salary)
	{
		System.out.println("1 double param");
	}
	
	
	//3. The Sequence of datatype of the arguments used in the constructors should be different
	Overload(String name, int age)
	{
		System.out.println("1 string & 1 int param");
	}
	
	Overload(int age, String name)
	{
		System.out.println("1 int & 1 String param");
	}
}


public class ConstructorOverloading {
	public static void main(String[] args) {
		Overload overload1 = new Overload();
		Overload overload2 = new Overload("Modi");
		Overload overload3 = new Overload(71);
		Overload overload4 = new Overload(9999.99);
		Overload overload5 = new Overload("Kalam", 71);
		Overload overload6 = new Overload(71, "Modi");
	}
}
