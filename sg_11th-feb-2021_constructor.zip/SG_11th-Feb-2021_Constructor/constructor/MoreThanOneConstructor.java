package constructor;

class Example
{
	Example()
	{
		System.out.println("Default constructor");
	}
	
	Example(String name)
	{
		System.out.println("1 string param");
	}
	
	Example(int age)
	{
		System.out.println("1 int param");
	}
}

public class MoreThanOneConstructor {
	public static void main(String[] args) {
		Example ex1 = new Example();
		
		Example ex2 = new Example("Modi");
		
		Example ex3 = new Example(71);
	}
}
