package constructor;

class SampleDemo
{
	SampleDemo(String name)
	{
		System.out.println("1 string param");
	}
	
	
	SampleDemo(){
		System.out.println("Default constructor");
	}
}



public class ParamConstructorWillRemoveDefaultConstructor {
	public static void main(String[] args) {
		SampleDemo s1 = new SampleDemo();
		System.out.println("**********************");
		
		SampleDemo s2 = new SampleDemo("Kalam");
	}
}
