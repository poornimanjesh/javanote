package constructor;


class Sample
{
	//Instance variable
	String name;
}

public class ClassWillHaveDefaultConstructor {
	public static void main(String[] args)
	{
		Sample s1 = new Sample();
		s1.name = "NaMo";
		System.out.println(s1.name);
	}
}
