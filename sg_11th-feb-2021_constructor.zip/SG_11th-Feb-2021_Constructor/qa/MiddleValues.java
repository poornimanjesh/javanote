package qa;

public class MiddleValues {
	public static void main(String[] args) {
		//Q: WAP for the array to find the middle value
		
		int arr[] = {1, 2, 3, 4, 5, 6 ,7, 8, 9};
		
		if((arr.length % 2)== 0) 
		{
			System.out.println(arr[(arr.length/2) - 1]);
			System.out.println(arr[arr.length/2]);
		}else 
		{
			System.out.println(arr[arr.length/2]);
		}
	}
}
