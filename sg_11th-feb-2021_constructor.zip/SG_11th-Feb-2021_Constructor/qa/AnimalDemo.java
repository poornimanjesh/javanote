package qa;

class Animal
{
	//Instance Members
	String breed;
	String habitate;
	int legs;
	int height;
	
	Animal(String breed, String habitate, int legs, int ht)
	{
		this.breed = breed;
		this.habitate = habitate;
		this.legs = legs;
		this.height = ht;
		
		System.out.println("Breed: " + this.breed);
		System.out.println("habitate: " + this.habitate);
		System.out.println("legs: " + this.legs);
		System.out.println("height: " + this.height);
	}
	
}
public class AnimalDemo {
	public static void main(String[] args) 
	{
		Animal tiger = new Animal("Natural", "Wild", 4, 5);
		System.out.println("**********************");
		Animal lion = new Animal("NAtural", "Wild", 4, 6);
		System.out.println("**********************");
		Animal cow = new Animal("Natural/Hybrid", "Domestic", 4, 5);
	}
}
