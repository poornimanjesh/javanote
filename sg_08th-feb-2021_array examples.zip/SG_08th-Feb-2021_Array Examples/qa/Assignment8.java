package qa;

import java.util.Arrays;

public class Assignment8 {
	public static void main(String[] args) {
		//Q: Find the missing values in a array?
		
		int a[] = {0, 1, 3, 5, 9};
		
		Arrays.sort(a);
		
		int max = a[a.length-1];
		
		int index = 0;
		for(int i=0; i<max; i++)
		{
			if(i==a[index])
			{
				index++;
			}else {
				System.out.println(i);
			}
		}
	}
}
