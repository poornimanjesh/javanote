package qa;

public class Assignment6 {
	public static void main(String[] args) {
		//Q: Find the duplicate values in a array?
		
		int a[] = {1, 2, 2, 2, 3, 1, 4, 5, 6, 4, 7, 2, 2};
		String s = "";
		
		for(int i=0; i<a.length; i++)
		{
			if(!s.contains(String.valueOf(a[i]))) 
			{
				for(int j=i+1; j<a.length; j++)
				{
					if(a[i] == a[j])
					{
						System.out.println(a[i]);
						s+= String.valueOf(a[i]);
						break;
					}
				}
			}
		}
	}
}
