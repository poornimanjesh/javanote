package qa;

public class Assignment3 {
	public static void main(String[] args) {
		//Q: Assign 2 D array to 1 D array?
		int arr1[][] = {{10, 20, 30}, {40, 50, 60}};
		
		System.out.println("Multi D array");
		for(int x1[]: arr1) {
			for(int x2 : x1) {
				System.out.print(x2+" ");
			}
			System.out.println();
		}
		
		
		int arr2[] = new int[arr1.length * arr1[0].length];
		int x = 0;
		for(int i=0; i<arr1.length; i++)
		{
			for(int j=0; j<arr1[i].length; j++)
			{
				arr2[x] = arr1[i][j];
				x++;
			}
		}
		
		
		//Display the output
		System.out.println("Single D array");
		for(int i=0; i<arr2.length; i++)
		{
			System.out.println(arr2[i]);
		}
		
	}
}
