package qa;

import java.util.Arrays;

public class Assignment4 {
	public static void main(String[] args) {
		//Q: Copy 1 array to another array?
		
		int a[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		System.out.println(Arrays.toString(a));
		
		int b[] = a.clone();
		System.out.println(Arrays.toString(b));
		
		int c[] = a;
		System.out.println(Arrays.toString(c));
		
		int d[] = Arrays.copyOf(a, a.length);
		System.out.println(Arrays.toString(d));
		
		
		int e[] = new int[a.length];
		for(int i=0; i<e.length; i++)
		{
			e[i] = a[i];
		}
		System.out.println(Arrays.toString(e));
		
	}
}
