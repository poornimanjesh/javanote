package qa;

public class Assignment9 {
	public static void main(String[] args) {
		//Q: How to compare 2 arrays?
		
		int a[] = {1, 2, 3, 4, 5};
		int b[] = {1, 2, 3, 4, 5};
		
		if(a.length == b.length) {
			boolean flag = false;
			
			for(int i=0; i<a.length; i++)
			{
				if(a[i] != b[i]) {
					flag = true;
					break;
				}
			}
			
			if(flag==true) System.out.println("Not same");
			else System.out.println("Both are same");
		}
		else {
			System.out.println("Sizes are uneven hence Both are not same.");
		}
	}

}
