package qa;

import java.util.Arrays;

public class BubbleSorting {
	public static void main(String[] args) {
		int a[] = {9, 1, 6, 2, 8, 4, 6, 5};
		System.out.println("Before:");
		System.out.println(Arrays.toString(a));
		
		for(int i=0; i<a.length; i++)
		{
			for(int j=i+1; j<a.length; j++)
			{
				if(a[i] < a[j])
				{
					int temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
			System.out.println(a[i]);
		}
	}
}
