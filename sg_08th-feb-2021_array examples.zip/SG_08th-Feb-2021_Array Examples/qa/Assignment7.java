package qa;

import java.util.Arrays;

public class Assignment7 {
	public static void main(String[] args) {
		//Q: Reverse the array?
		
		int a[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		System.out.println("Before:");
		System.out.println(Arrays.toString(a));
		
		System.out.println("After:");
		for(int i=a.length-1; i>=0; i--)
		{
			System.out.print(a[i]+" ");
		}
	}
}
