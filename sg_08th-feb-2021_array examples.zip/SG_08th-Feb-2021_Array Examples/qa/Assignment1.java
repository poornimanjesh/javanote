package qa;

public class Assignment1 {
	public static void main(String[] args) {
		//Q: Can we create a blank array?
		
		int arr[] = {};
	}
}
