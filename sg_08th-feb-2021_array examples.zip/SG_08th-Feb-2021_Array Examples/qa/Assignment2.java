package qa;

public class Assignment2 {
	public static void main(String[] args) {
		//Q: Assign 1 D array to 2 D array?
		
		int arr1[] = {10, 20, 30, 40, 50, 60};
		System.out.println("Single D Array");
		for(int a: arr1) {
			System.out.println(a);
		}
		
		System.out.println();
		
		int arr2[][] = new int[3][2];
		
		int x = 0;
		for(int i=0; i<arr2.length; i++)
		{
			for(int j=0; j<arr2[i].length; j++)
			{
				arr2[i][j] = arr1[x];
				x++;
			}
		}

		
		//Display the 2 D Array
		System.out.println("Multi D Array");
		for(int x1[]: arr2) {
			for(int x2: x1) {
				System.out.print(x2+" ");
			}
			System.out.println();
		}
	}
}
