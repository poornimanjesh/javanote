package qa;

import java.util.Arrays;

public class CopyUnEvenSizedArrays {
	public static void main(String[] args) {
		//Q: Copy one array to another array which are having uneven sizes
		
		int a[] = {1, 2, 3, 4, 5};
		int b[] = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
		System.out.println("Before: Original values");
		System.out.println(Arrays.toString(a));
		System.out.println(Arrays.toString(b));
		
		int temp[] = b;
		b = a;
		a = temp;
		
		System.out.println("After: Values are swaped");
		System.out.println(Arrays.toString(a));
		System.out.println(Arrays.toString(b));
		
		
	}
}
