package qa;

import java.util.Arrays;

public class Assignment5 {
	public static void main(String[] args) {
		//Q: Sort the array values?
		int a[] = {9, 1, 6, 2, 8, 4, 6, 5};
		System.out.println("Before:");
		System.out.println(Arrays.toString(a));
		
		Arrays.sort(a);
		System.out.println("After:");
		System.out.println(Arrays.toString(a));
	}

}
