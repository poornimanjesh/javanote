package arrayDemo;

public class ArrayAcceptsObject {
	public static void main(String[] args) {
		Object arr[] = new Object[5];
		arr[0] = "A";
		arr[1] = "B";
		arr[2] = "C";
		arr[3] = "D";
		arr[4] = "E";
		
		System.out.println(arr.length);
		
		for(Object obj : arr) {
			System.out.println(obj);
		}
	}
}
