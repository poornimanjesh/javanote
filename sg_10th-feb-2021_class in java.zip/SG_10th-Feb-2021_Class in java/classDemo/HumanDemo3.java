package classDemo;

class Human2
{
	//Instance variables (states)
	String FN;
	String LN;
	int age;
	
	//To assign the values to instance variables we must use either constructor OR methods
	Human2(String first, String last, int age)	//Parameterized Constructor
	{
		FN = first;
		LN = last;
		this.age = age;
		
		System.out.println("First Name is: " + FN);
		System.out.println("Last Name is: " + LN);
		System.out.println("Age is: " + this.age);
	}
}


public class HumanDemo3 {	
	public static void main(String[] args) 
	{
		Human2 kalam = new Human2("Abdul", "Kalam", 71);
		
		System.out.println("*************************************");
		
		Human2 modi = new Human2("Narendra", "Modi", 71);
	}
}
