package classDemo;

class Human1
{
	//Instance variables (states)
	String FN;
	String LN;
	int age;
	
	//To assign the values to instance variables we must use either constructor OR methods
	Human1()	//Default Constructor
	{
		FN = "Abdul";
		LN = "Kalam";
		age = 71;
		
		System.out.println("First Name is: " + FN);
		System.out.println("Last Name is: " + LN);
		System.out.println("Age is: " + age);
	}
}


public class HumanDemo2 {	
	public static void main(String[] args) 
	{
		Human1 kalam = new Human1();
		
		System.out.println("*************************************");
		
		Human1 modi = new Human1();
	}
}
