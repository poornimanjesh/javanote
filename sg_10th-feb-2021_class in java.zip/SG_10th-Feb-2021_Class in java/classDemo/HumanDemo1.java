package classDemo;

public class HumanDemo1 {
	//Instance variables (states)
	String FN;
	String LN;
	int age;
	
	public static void main(String[] args) 
	{
		HumanDemo1 kalam = new HumanDemo1();
		kalam.FN = "Abdul";
		kalam.LN = "Kalam";
		kalam.age = 71;
		
		System.out.println("First Name is: " + kalam.FN);
		System.out.println("Last Name is: " + kalam.LN);
		System.out.println("Age is: " + kalam.age);
		
		System.out.println("*************************************");
		
		HumanDemo1 modi = new HumanDemo1();
		modi.FN = "Narendra";
		modi.LN = "Modi";
		modi.age = 71;
		
		System.out.println("First Name is: " + modi.FN);
		System.out.println("Last Name is: " + modi.LN);
		System.out.println("Age is: " + modi.age);
	}
}
