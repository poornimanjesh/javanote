package qa;

class Test
{
	public void A() {System.out.println("method A()");}
	public void B() {System.out.println("method B()");}
	public void C() {System.out.println("method C()");}
	
	Test() {
		System.out.println("Default constructor");
		A();
		B();
		C();
		System.out.println("*****************");
	}
	
	{
		System.out.println("Instance block");
		A();
		B();
		C();
		System.out.println("*****************");
	}
	
	/*static
	{
		System.out.println("Static block");
		Test t = new Test();
		t.A();
		t.B();
		t.C();
		System.out.println("*****************");
	}*/
}

public class Assignment1 {
	public static void main(String[] args) {
		Test t1 = new Test();
		
		/*t1.A();
		t1.B();
		t1.C();*/
	}
}
