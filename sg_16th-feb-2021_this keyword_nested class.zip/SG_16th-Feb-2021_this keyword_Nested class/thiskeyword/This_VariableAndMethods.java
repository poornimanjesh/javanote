package thiskeyword;

class Sample1
{
	int accNum;
	String name;
	
	public void A() {System.out.println("method A()");}
	public void B() {System.out.println("method B()");}
	
	Sample1(int accNum, String name)
	{
		this.accNum = accNum;
		this.name = name;
		System.out.println("Name: "+this.name + " & accNumber is: "+ this.accNum);
		this.A();
		this.B();
	}
	
	public void method1(int accNum, String name)
	{
		this.accNum = accNum;
		this.name = name;
		System.out.println("Name: "+this.name + " & accNumber is: "+ this.accNum);
		this.A();
		this.B();
	}
	
}


public class This_VariableAndMethods {
	public static void main(String[] args) {
		Sample1 s1 = new Sample1(123456, "Modi");
		
		System.out.println("*********************");
		
		s1.method1(999999, "Kalam");
	}
}
