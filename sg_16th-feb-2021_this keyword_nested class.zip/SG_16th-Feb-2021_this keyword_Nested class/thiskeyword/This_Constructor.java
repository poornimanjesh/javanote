package thiskeyword;

class Sample2
{
	//Constructor won't return any value. But I want to 
	//take the value from one constructor & use in another constructor
	//Q: L*B*H = volume
	
	int height;
	
	Sample2(int height)
	{
		//Constructor 1
		this.height = height;
	}
	
	Sample2(int height, int length, int breadth)
	{
		//Constructor 2
		this(height);
		int volume = length * breadth * this.height;
		System.out.println("volume:"+ volume);
	}
}


public class This_Constructor {
	public static void main(String[] args) {
		Sample2 s1 = new Sample2(10, 11, 12);
	}
}
