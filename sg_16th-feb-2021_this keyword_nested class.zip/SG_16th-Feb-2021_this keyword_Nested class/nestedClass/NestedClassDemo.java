package nestedClass;

class Outer
{
	String name = "Modi";
	int age = 71;
	Inner in = new Inner();
	
	public void A() {System.out.println("Outer: method A()");}
	
	Outer(){
		System.out.println("Outer class Constructor");
		System.out.println(in.city);
		System.out.println(in.pinCode);
		in.B();
	}
	
	
	
	class Inner
	{
		String city = "Raichur";
		int pinCode = 568124;
		public void B() {System.out.println("Inner: method B()");}
		
		Inner()
		{
			System.out.println("Inner class Constructor");
			System.out.println(name);
			System.out.println(age);
			A();
			System.out.println("**********************");
		}
	}
}


public class NestedClassDemo {
	public static void main(String[] args) {
		Outer out = new Outer();
	}
}
