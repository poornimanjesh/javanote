package arrayDemo;

public class SingleDArray_1 {
	public static void main(String[] args) {
		int arr[] = new int[5];
		
		arr[0] = 10;
		arr[1] = 20;
		arr[2] = 30;
		arr[3] = 40;
		arr[4] = 50;
		
		System.out.println("Array Size: " + arr.length);
		
		System.out.println("*********** FOR LOOP***************");
		for(int i=0; i<arr.length; i++)
		{
			System.out.println(arr[i]);
		}
		
		
		System.out.println("*********** FOR EACH LOOP***************");
		for(int x : arr)
		{
			System.out.println(x);
		}
		
		
		System.out.println("*********** WHILE LOOP***************");
		int i = 0;
		while(i < arr.length)
		{
			System.out.println(arr[i]);
			i++;
		}
		
		
		System.out.println("***********DO WHILE LOOP***************");
		int j = 0;
		do
		{
			System.out.println(arr[j]);
			j++;
		}while(j < arr.length);
	}
}
