package arrayDemo;

public class MultiDArray_2 {
	public static void main(String[] args) {
		String str[][] = {{"A", "B"}, {"C", "D"}, {"E", "F"}};
		
		
		System.out.println("Rows: " + str.length);
		System.out.println("Columns: " + str[0].length);
		
		System.out.println("*********** FOR LOOP *******************");
		
		for(int i=0; i<str.length; i++)
		{
			for(int j=0; j<str[i].length; j++)
			{
				System.out.print(str[i][j]+ " ");
			}
			System.out.println();
		}
		
		
		System.out.println("*********** FOR EACH LOOP *******************");
		
		for(String s1[] : str)
		{
			for(String s2: s1)
			{
				System.out.print(s2 +" ");
			}
			System.out.println();
		}
		
		System.out.println("*********** WHILE LOOP *******************");
		
		int i = 0;
		while( i < str.length)
		{
			int j = 0;
			
			while(j < str[i].length)
			{
				System.out.print(str[i][j] + " ");
				j++;
			}
			System.out.println();
			i++;
		}
		
		System.out.println("*********** DO WHILE LOOP *******************");
		
		int m = 0;
		do
		{
			int n = 0;
			do
			{
				System.out.print(str[m][n]+ " ");
				n++;
			}while(n < str[m].length);
			System.out.println();
			m++;
		}while(m < str.length);
	}
}
