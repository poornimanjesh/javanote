package breakandcontinue;

public class Break_NestedLoop {
	public static void main(String[] args) {
		//Q: Check for country and state. If the state is "KA" in India then stop the loop
		String country[] = {"USA", "UK", "INDIA", "JP", "ZZ", "XX"};
		String states[] = {"AP", "TN", "KA", "UP", "MP"};
		
		int flag = 0;
		for(int i=0; i<6; i++)
		{
			System.out.println(country[i]);
			if(country[i].equals("INDIA")) 
			{
				for(int j=0; j<5; j++)
				{
					if(states[j].equals("KA")) {
						System.out.println("State KA matched.");
						flag = 1;
						break;
					}
				}
			}
			
			if(flag == 1) {
				System.out.println("As inner loop stoped. HEnce stopping the outer loop");
				break;
			}
		}
	}
}
