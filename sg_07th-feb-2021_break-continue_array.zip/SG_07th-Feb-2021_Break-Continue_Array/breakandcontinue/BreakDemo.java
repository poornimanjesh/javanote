package breakandcontinue;

public class BreakDemo {
	public static void main(String[] args) {
		//Q: display from 1 to 10 & stop the loop when the iteration reaches 5.
		
		for(int i=1; i<=10; i++)
		{
			System.out.println("i value is: " + i);
			
			if(i == 5) {
				System.out.println("Condition matched.");
				break;
			}
			
			System.out.println("%%%");
		}
	}
}
