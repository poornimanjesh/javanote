package breakandcontinue;

public class Continue_CityName {
	public static void main(String[] args) {
		//Q: Except bangalore check for all the cities.
		String str[] = {"Mumbai", "Hubballi", "Bangalore", "Raichur", "Dharwad"};
		
		for(int i=0; i<5; i++)
		{
			System.out.println(str[i]);
			if(str[i].equals("Bangalore")) {
				continue;
			}
			
			System.out.println("-------------------");
			System.out.println("*******************");
			System.out.println("$$$$$$$$$$$$$$$$$");
			System.out.println("%%%%%%%%%%%%%%%%%");
		}
	}
}
