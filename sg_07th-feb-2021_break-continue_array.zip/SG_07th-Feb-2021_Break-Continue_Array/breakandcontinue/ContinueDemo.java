package breakandcontinue;

public class ContinueDemo {
	public static void main(String[] args) {
		//Q: loop from 1 to 10. If iteration becomes 5 then skip 5th iteration
		
		for(int i=1; i<=10; i++)
		{
			System.out.println("i value: "+ i);
			
			if(i == 5) {
				System.out.println("Condition matched");
				continue;
			}
			
			System.out.println("@");
			System.out.println("$");
			System.out.println("%");
		}
	}
}
