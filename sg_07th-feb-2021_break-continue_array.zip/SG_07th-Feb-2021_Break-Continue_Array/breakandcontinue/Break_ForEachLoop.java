package breakandcontinue;

public class Break_ForEachLoop {
	public static void main(String[] args) {
		//Q: Break the loop after 5th iteration
		int arr[] = new int[10];
		
		int i = 0;
		for(int x : arr) {
			System.out.println(x);
			i++;
			
			if(i == 5) {
				System.out.println("Condition matched");
				break;
			}
		}
	}
}
