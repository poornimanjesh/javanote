package qa;

import java.util.Arrays;

public class Assignment4 {
	public static void main(String[] args) {
		Object arr[] = new Object[5];
		arr[0] = 10;
		arr[1] = "String";
		arr[2] = true;
		arr[3] = 10.50;
		arr[4] = 'A';
		
		System.out.println(Arrays.toString(arr));
	}
}
