package qa;

import java.util.Arrays;
import java.util.List;

public class Assignment3 {
	public static void main(String[] args) {
		//Q: Is it possible to convert the array to collection?
		Integer arr[] = {1, 2, 3, 4, 5};
		List<Integer> oList1 = Arrays.asList(arr);
		System.out.println(oList1);
		
		
				
		String str[] = {"A", "B", "C", "D", "E"};
		List<String> oList2 = Arrays.asList(str);
		System.out.println(oList2);
	}
}
