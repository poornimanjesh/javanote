package qa;

import java.util.Arrays;

public class Assignment1 {
	public static void main(String[] args) {
		//Q: Addition of 2 arrays?
		
		int a[] = {1, 2, 3, 4, 5};
		int b[] = {10, 11, 12, 13, 14};
		
		int res[] = new int[a.length];
		
		if(a.length == b.length)
		{
			for(int i=0; i<a.length; i++)
			{
				res[i] = a[i] + b[i];
			}
			
			System.out.println(Arrays.toString(res));
		}else {
			System.out.println("Uneven sizes. Can't perform addition operations");
		}
	}
}
