package qa;

public class Assignment5 {
	public static void main(String[] args) {
		//Q: Write a programme to find the addition of 2 elements in a 
		//array is equal to the given number?
		
		int arr[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		int num = 8;
		
		for(int i=0; i<arr.length; i++)
		{
			for(int j=i+1; j<arr.length; j++)
			{
				if((arr[i] + arr[j]) == num)
				{
					System.out.println(arr[i]+" + "+ arr[j]+" = " + (arr[i] + arr[j]));
				}
			}
		}
		
	}
}
