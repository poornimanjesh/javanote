package foreach;

public class ForEachLoop_1D {
	public static void main(String[] args) {
		//Q: for each loop for single D array of int datatype
		int arr[] = {10, 20, 30, 40, 50};
		
		for(int x : arr)
		{
			System.out.println(x);
		}
		
		System.out.println("****************************************");
		
		//Q: for each loop for single D array of String datatype
		String str[] = {"Apple", "Boy", "Cat", "Dog", "Eagle", "Fox"};
		
		for(String s : str)
		{
			System.out.println(s);
		}
		
	}
}
