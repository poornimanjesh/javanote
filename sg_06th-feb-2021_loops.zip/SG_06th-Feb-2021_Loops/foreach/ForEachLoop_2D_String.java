package foreach;

public class ForEachLoop_2D_String {
	public static void main(String[] args) {
		String sss[][] = {{"A", "B", "C"}, {"D", "E", "F"}, {"G", "H", "I"}};
		
		for(String s[] : sss)
		{
			for(String s1 : s)
			{
				System.out.print(s1+ " ");
			}
			System.out.println();
		}
	}
}
