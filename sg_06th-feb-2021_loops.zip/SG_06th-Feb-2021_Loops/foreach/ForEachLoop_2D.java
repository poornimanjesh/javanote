package foreach;

public class ForEachLoop_2D {
	public static void main(String[] args) {
		int arr[][] = {{10, 20, 30}, {40, 50, 60}, {70, 80, 90}};
		
		//10 20 30
		//40 50 60
		//70 80 90
		
		for(int x1[] : arr)
		{
			for(int x2 : x1)
			{
				System.out.print(x2+" ");
			}
			System.out.println();
		}
	}
}
