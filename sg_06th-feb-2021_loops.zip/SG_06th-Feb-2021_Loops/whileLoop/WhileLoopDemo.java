package whileLoop;

public class WhileLoopDemo {
	public static void main(String[] args) {
		//Q: Print 1 to 9 numbers
		int n = 1;
		
		while( n < 10) {
			System.out.println("Inside the loop: " + n);
			n++;
		}
		
		System.out.println("#####################");
		
		//Q: print 1 to 100. If you get the value which is divisible by 19 then stop the loop
		
		int x = 1;
		while(x <= 100)
		{
			//System.out.println(x);
			if((x%19) == 0) {
				System.out.println("Codition matched when the x value reached : " + x);
				break;
			}
			x++;
		}
	}
}
