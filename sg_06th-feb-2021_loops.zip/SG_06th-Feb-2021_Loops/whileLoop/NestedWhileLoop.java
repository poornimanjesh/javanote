package whileLoop;

public class NestedWhileLoop {
	public static void main(String[] args) {
		//Q: print below pattern
		//*
		//* *
		//* * *
		
		int row = 1;
		while(row <= 3)
		{
			int column = 1;
			while(column <= row)
			{
				System.out.print("* ");
				column++;
			}
			System.out.println();
			row++;
		}
	}
}
