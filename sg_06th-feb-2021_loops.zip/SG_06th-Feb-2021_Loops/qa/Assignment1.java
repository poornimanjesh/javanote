package qa;

public class Assignment1 {
	public static void main(String[] args) {
		//Q: Print * * * using for each loop
		
		int a[] = new int[3];
		
		for(int x : a)
		{
			System.out.print("* ");
		}
		System.out.println();
		
		System.out.println("########################");
		
		//Q: print below pattern
		//*
		//*
		//*
		//*
		int b[] = new int[4];
		for(int y : b)
		{
			System.out.println("*");
		}
	}
}
