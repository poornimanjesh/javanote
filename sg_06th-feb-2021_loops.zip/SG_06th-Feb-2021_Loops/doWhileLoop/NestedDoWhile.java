package doWhileLoop;

public class NestedDoWhile {
	public static void main(String[] args) {
		//Q: Print the pyramid using do while loop
		//    *
		//  *   *
		//*   *   *
		
		int row = 1;
		do
		{
			int cols = 1;
			do
			{
				if((row + cols) <= 4)
				{
					System.out.print(" ");
				}else {
					System.out.print("*");
					System.out.print(" ");
				}
				cols++;
			}while( cols <=4 );
			System.out.println();
			
			row++;
		}while( row <= 4 );
	}
}
