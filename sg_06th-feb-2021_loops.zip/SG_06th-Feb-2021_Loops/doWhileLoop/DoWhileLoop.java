package doWhileLoop;

public class DoWhileLoop {
	public static void main(String[] args) {
		//Q: Print * * * * * 
		
		int i = 1;
		do
		{
			System.out.print("* ");
			i++;
		}while(i <= 5 );
		
		System.out.println();
		System.out.println("#######################");
		
		//Q: print 5 *'s vertically
		//*
		//*
		//*
		//*
		//*
		
		int j = 1;
		
		do
		{
			System.out.println("*");
			j++;
		}while(j <=5 );
	}
}
